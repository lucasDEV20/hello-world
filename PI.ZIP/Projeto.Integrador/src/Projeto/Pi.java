package Projeto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Pi {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        // TODO Auto-generated method stub
        
        int opçao = 0;
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA); 
        
        System.out.println("\n");
        System.out.println("          -------------------------------------------------   MORFEL   -------------------------------------------------          ");
        System.out.println("\n\n");

        do{   
            
            menu();   

            while (!leia.hasNextInt()) {  
                String input = leia.next();
                System.out.println("");
                System.out.println("Erro!!!");
                System.out.println("Digite apenas numeros presentes no menu:");
                System.out.println("");
                
                menu();  
                
            }
            opçao = leia.nextInt();

            switch(opçao){   
                case 0:   
                    Sair(); 
                    break;   

                case 1:   
                    Exibir_Matriz();   
                    break;      
                    
                case 2:     
                    Matriz_Similaridade();  
                    break;      

                case 3:     
                    Lista_Usuarios_Semelhantes();  
                    break;      
                    
                case 4:    
                    Dominante_Recessiva();   
                    break;      
            }
        } while(opçao != 0);    
    }
    
    public static void LeitorArquivo(String[] vetorDNA){    
        // TODO Auto-generated method stub
	String nome = "C:\\Users\\Computador\\Documents\\cadeiasDNA.txt";  
	
        try {     
        
            FileReader arq = new FileReader(nome);   
            BufferedReader lerArq = new BufferedReader(arq);
	 
            String linha = lerArq.readLine(); // lê a primeira linha
            // a variável "linha" recebe o valor "null" quando o processo
            // de repetição atingir o final do arquivo texto
            
            int i = 0;
	    
            while (linha != null) {    
                
                String[] basesDNA = linha.split(","); 
	    	 
                String palavra = "";
	    	
                for(int j = 0; j < basesDNA.length; j++){
                    palavra = palavra + basesDNA[j];
                }
	    	 
                //System.out.printf("%s\n", linha);
                //System.out.println(palavra);
	        
                vetorDNA[i] = palavra;
                i++;
	 
                linha = lerArq.readLine(); 
            }
	 
            arq.close();
        } catch (IOException e) {   
            System.err.printf("Erro na abertura do arquivo: %s.\n", e.getMessage());
        }
    }
    
    public static void imprimeVetor(String[] vetor) {  
	for (int i = 0; i < vetor.length; i++) {     
            System.out.println("Pessoa["+i+"] = " + vetor[i]);  
	}
    }
    
    public static void menu(){  

        System.out.println("____________________________________________________");
        System.out.println("                    Menu                       ");
        System.out.println("0 - Sair.");
        System.out.println("1 - Exibir Matriz com as Cadeias de DNA.");
        System.out.println("2 - Computar e exibir a matriz de similaridade.");
        System.out.println("3 - Apresentar Lista de Usuários Semelhantes.");
        System.out.println("4 - Apresentar a Base Dominante e Recessiva.");
        System.out.println("\nEcolha uma das opções:");
        System.out.println("____________________________________________________");
    }

    public static void Sair(){       
        System.out.println("");
        System.out.println("Finalizando...");
    }

    public static void Exibir_Matriz(){    
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA); 
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("   Exibir Matriz com as Cadeias de DNA"); 
        System.out.println("\nVetor Cadeias DNA:");
        System.out.println("");
        imprimeVetor(cadeiasDNA); 
        System.out.println("");
    }

    public static void Matriz_Similaridade(){      
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA);    
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("Computar e exibir a matriz de similaridade");
        System.out.println("");
        System.out.println("     Matriz de similaridade");
        System.out.println("");
        Matriz_LCS();   
        System.out.println("");
    }
    
    public static void Matriz_LCS(){    
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA);     
        
        Pi lcs = new Pi(); 
        
        for (int i = 0; i < cadeiasDNA.length; i++) {  
            for (int j = 0; j < cadeiasDNA.length; j++) {  

                char[] X=cadeiasDNA[i].toCharArray(); 
                char[] Y=cadeiasDNA[j].toCharArray();     
                int m = X.length;     
                int n = Y.length;      
                
                if(i!=j){
                    System.out.println("ID " + i + " com ID "+ j +" e de tamanho: "+ lcs.lcs(X, Y, m, n) ); 
                }
                else{
                    System.out.println("ID " + i + " com ID "+ j +" e de tamanho: "+"MAX" ); 

                }
            }
        }
    }
    
    public static void Lista_Usuarios_Semelhantes(){    
        Scanner leia = new Scanner(System.in);
        
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA);     
        
        int maior = 0, cont =0, tamanho, flag =1, var, id;
        String opcao;
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("Apresentar Lista de Usuários Semelhantes");
        System.out.println("");
               
        while (flag == 1) {  
            
            System.out.println("Digite o ID desejado:");
            opcao = leia.next();
            System.out.println("");
            try {       
                var = Integer.parseInt(opcao);
                
                if (var > 99 || var < 0) {   
                    System.out.println("Erro!!!");
                    System.out.println("Digite apenas numeros entre 0 a 99");
                    System.out.println("");
                    flag = 1;
                } else {    
                    flag = 0;
                    id = var;
                }
            } catch (NumberFormatException e) { 
                System.out.println("\nErro!!!Digite apenas numeros entre 0 a 99");
                flag = 1;
            }
        }

        Pi lcs = new Pi(); 
        
        for (String cadeiasDNA1 : cadeiasDNA) {
            char[] X = cadeiasDNA1.toCharArray();
            char[] Y = cadeiasDNA1.toCharArray();
            int m = X.length; 
            int n = Y.length;
            tamanho = lcs.lcs(X, Y, m, n);
            for (int j = 0; j < 5; j++) {
                
            }
        }
        
        System.out.println("");
    }
        
    public static void Dominante_Recessiva(){  
        Scanner leia = new Scanner(System.in);
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("Apresentar a Base Dominante e Recessiva");
        System.out.println("");
        
        int opçao2;
        
        do{
            
            subMenu();  
            
            while (!leia.hasNextInt()) { 
                String input = leia.next();
                    
                System.out.println("");
                System.out.println("Erro!!!");
                System.out.println("Digite apenas numeros presentes no menu");
                System.out.println("");
                
                subMenu();
            }
            opçao2 = leia.nextInt();  
                
            switch(opçao2){
                case 1:  
                    DrGeral();   
                    break;  
                case 2:    
                    DrPessoa();    
                    break;
                case 0:
                    System.out.println("");
                    System.out.println("Voltando pro menu principal.");
        }
        System.out.println("");
    
        }while(opçao2!=0);
    }
    
    public static void subMenu(){  
        System.out.println("_____________________________");
        System.out.println("           Menu           ");
        System.out.println("1 - Geral.");
        System.out.println("2 - Por pessoa.");
        System.out.println("0 - Sair");
        System.out.println("\nEcolha uma das opções:");
        System.out.println("______________________________");
        
    }
    
    public static void DrGeral(){  
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA); 
        
        char A, C, G, T;
        int a=0, c=0, g=0, t=0;
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("\nDominante e recessivo das cadeias de DNA em geral:");
        System.out.println("");
        
        for (int i = 0; i < cadeiasDNA.length; i++) {   
            for (int j = 0; j < 30; j++) {  
                char[] s = cadeiasDNA[i].toCharArray(); 
                                 
                if(s[j]=='A'){  
                    a++;
                }
                if(s[j]=='C'){  
                    c++;
                }
                if(s[j]=='G'){  
                    g++;
                }
                if(s[j]=='T'){  
                    t++;
                }
                
            }
        }
        System.out.println("Dominante:");
        if(a>c && a>g && a>t){  
            System.out.println("Adenina");
        }
        else if(c>a && c>g && c>t){ 
            System.out.println("Citosina");
        }
        else if(g>c && g>a && g>t){ 
            System.out.println("Guanina");
        }
        else if(t>c && t>a && t>g){ 
            System.out.println("Tinina");
        }
        System.out.println("______________");
        System.out.println("");
        System.out.println("Recessivo:");
        if(a<c && a<g && a<t){  
            System.out.println("Adenina");
        }
        else if(c<a && c<g && c<t){  
            System.out.println("Citosina");
        }
        else if(g<c && g<a && g<t){ 
            System.out.println("Guanina");
        }
        else if(t<c && t<a && t<g){ 
            System.out.println("Tinina");
        }
        System.out.println("");
    }
    
    public static void DrPessoa(){
        Scanner leia = new Scanner(System.in);
        
        String[] cadeiasDNA = new String[100];	
	LeitorArquivo(cadeiasDNA);
        
        char A, C, G, T;
        int a=0, c=0, g=0, t=0,  flag =1, var = 0, id;
        String opcao;
        
        System.out.println("");
        System.out.println("Opção escolhida:");
        System.out.println("");
        System.out.println("Dominante e recessivo das cadeias de DNA por pessoa:");
        System.out.println("");
        
        while (flag == 1) {   
            System.out.println("Digite o ID desejado:");
            opcao = leia.next();
            System.out.println("");
            try {    
                var = Integer.parseInt(opcao);
                if (var > 99 || var < 0) { 
                    System.out.println("Erro!!!");
                    System.out.println("Digite apenas numeros entre 0 a 99");
                    System.out.println("");
                    flag = 1;
                } else {    
                    flag = 0;
                    id = var;
                }
            } catch (Exception e) {     
                System.out.println("\nErro!!!Digite apenas numeros entre 0 a 99");
                flag = 1;
            }
        }
        
        for (int i = 0; i < cadeiasDNA.length; i++) {   
            for (int j = 0; j < 30; j++) {
                char[] s = cadeiasDNA[var].toCharArray();  
                                
                if(s[j]=='A'){  
                    a++;
                }
                if(s[j]=='C'){  
                    c++;
                }
                if(s[j]=='G'){  
                    g++;
                }
                if(s[j]=='T'){  
                    t++;
                }
                
            }
        }
        System.out.println("Dominante:");
        if(a>c && a>g && a>t){  
            System.out.println("Adenina");
        }
        else if(c>a && c>g && c>t){
            System.out.println("Citosina");
        }
        else if(g>c && g>a && g>t){
            System.out.println("Guanina");
        }
        else if(t>c && t>a && t>g){   
            System.out.println("Tinina");
        }
        System.out.println("______________");
        System.out.println("");
        System.out.println("Recessivo:");
        if(a<c && a<g && a<t){  
            System.out.println("Adenina");
        }
        else if(c<a && c<g && c<t){  
            System.out.println("Citosina");
        }
        else if(g<c && g<a && g<t){  
            System.out.println("Guanina");
        }
        else if(t<c && t<a && t<g){  
            System.out.println("Tinina");
        }
        System.out.println("");
    }
    
    int lcs( char[] X, char[] Y, int m, int n ) {   //metodo pra retornar o valor do lcs
        //Retorna o comprimento do LCS para X [0..m-1], Y [0..n-1] 
        int L[][] = new int[m+1][n+1]; 
       
        for (int i=0; i<=m; i++) { 
            for (int j=0; j<=n; j++) { 
                if (i == 0 || j == 0) 
                    L[i][j] = 0; 
                else if (X[i-1] == Y[j-1]) 
                    L[i][j] = L[i-1][j-1] + 1; 
                else
                    L[i][j] = Math.max(L[i-1][j], L[i][j-1]); 
            } 
        } 
    
    return L[m][n];     
    } 
        
    int max(int a, int b) { 
        
        return (a > b)? a : b; 
    }
}